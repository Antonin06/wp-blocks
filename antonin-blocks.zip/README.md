# wp-blocks

```bash
nvm use 22

npm i

# lance le docker
npx wp-env start

# lance le dev des blocks
npm run dev

# have fun :) 
```
